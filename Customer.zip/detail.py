from tkinter import *
from PIL import Image,ImageTk
from tkinter import ttk
import mysql.connector
from time import strftime
from  datetime import  datetime
import random
from tkinter import messagebox




class DetailsRooms:
    def __init__(self,root):
        self.root=root
        self.root.title("Hotel Management System ")
        self.root.geometry("1120x510+230+180")

        lbl_title = Label(self.root, text="ROOM BOOKINGS", font=("times new roman", 18, "bold"), bg="black", fg="gold",relief=RIDGE, bd=4)
        lbl_title.place(x=0, y=0, width=1235, height=50)

        Img2 = Image.open(r"C:\Users\ABC\PycharmProjects\HotelManagementSystem\images\hotel images\logohotel.png")
        Img2 = Img2.resize((100, 40), Image.BILINEAR)
        self.photoImg2 = ImageTk.PhotoImage(Img2)

        lblimg = Label(self.root, image=self.photoImg2, bd=0, relief=RIDGE)
        lblimg.place(x=5, y=2, width=100, height=40)

        # ===================== Label frame=================
        labelframeleft = LabelFrame(self.root, bd=2, relief=RIDGE, text="New Room Add",font=("times new roman", 12, "bold"), bg="blue", padx=2)
        labelframeleft.place(x=5, y=50, width=430, height=450)

        # floor
        lbl_floor = Label(labelframeleft, text="FLOOR", font=("times new roman", 12, "bold"), padx=2,pady=6, bg="blue")
        lbl_floor.grid(row=0, column=0,sticky=W,padx=20)

        self.var_floor=StringVar()
        entry_floor = ttk.Entry(labelframeleft,textvariable=self.var_floor, width=18, font=("arial", 13, "bold"))
        entry_floor.grid(row=0, column=1, sticky=W)

        # room no
        lbl_roomno = Label(labelframeleft, text="ROOM NO", font=("times new roman", 12, "bold"), padx=2, pady=6, bg="blue")
        lbl_roomno.grid(row=1, column=0,sticky=W,padx=20)

        self.var_roomno=StringVar()
        entry_roomno = ttk.Entry(labelframeleft, textvariable=self.var_roomno,width=18, font=("arial", 13, "bold"))
        entry_roomno.grid(row=1, column=1, sticky=W)

        # roomtype
        lbl_roomtype = Label(labelframeleft, text="ROOM TYPE", font=("times new roman", 12, "bold"), padx=2, pady=6, bg="blue")
        lbl_roomtype.grid(row=2, column=0,sticky=W,padx=20)

        self.var_roomtype=StringVar()
        entry_roomtype = ttk.Entry(labelframeleft,textvariable=self.var_roomtype ,width=18, font=("arial", 13, "bold"))
        entry_roomtype.grid(row=2, column=1, sticky=W)

        # ===========================BTN=================================
        btn_frame = Frame(labelframeleft, bd=2, relief=RIDGE)
        btn_frame.place(x=20, y=385, width=350, height=36)

        add_btn = Button(btn_frame, text="ADD",command=self.Add_data,font=("arial", 13, "bold"), bg="black",
                         fg="gold", width=8)
        add_btn.grid(row=0, column=0, padx=1)

        update_btn = Button(btn_frame,text="UPDATE", command=self.update_data,font=("arial", 13, "bold"), bg="black",
                            fg="gold", width=8)
        update_btn.grid(row=0, column=1, padx=1)

        delete_btn = Button(btn_frame,text="DELETE",command=self.mdelete ,font=("arial", 13, "bold"), bg="black",
                            fg="gold", width=7)
        delete_btn.grid(row=0, column=2, padx=1)

        reset_btn = Button(btn_frame,text="RESET", command=self.reset,font=("arial", 13, "bold"), bg="black",
                           fg="gold", width=7)
        reset_btn.grid(row=0, column=3, padx=1)

        # ===================== tabel frame search system=================
        tabelframe = LabelFrame(self.root, bd=2, relief=RIDGE, text="SHOW ROOM",font=("times new roman", 12, "bold"), padx=2)
        tabelframe.place(x=500, y=50, width=600, height=300)

        scroll_x = ttk.Scrollbar(tabelframe, orient=HORIZONTAL)
        scroll_y = ttk.Scrollbar(tabelframe ,orient=VERTICAL)

        self.room_table = ttk.Treeview(tabelframe, columns=("floor","roomno","roomtype"),
                                       xscrollcommand=scroll_x,
                                       yscrollcommand=scroll_y)

        scroll_x.pack(side=BOTTOM, fill=X)
        scroll_y.pack(side=RIGHT, fill=Y)

        scroll_x.config(command=self.room_table.xview)
        scroll_y.config(command=self.room_table.yview)

        self.room_table.heading("floor", text="floor")
        self.room_table.heading("roomno", text="roomno")
        self.room_table.heading("roomtype", text="roomtype")

        self.room_table["show"] = "headings"

        self.room_table.column("floor", width=55)
        self.room_table.column("roomno", width=90)
        self.room_table.column("roomtype", width=85)

        self.room_table.pack(fill=BOTH, expand=1)
        self.room_table.bind("<ButtonRelease-1>", self.get_cursor)
        self.fetch_data()

    def Add_data(self):
        if self.var_floor.get()=="" or self.var_roomtype.get()=="" :
            messagebox.showerror("Error ", "Don't leave any fields ",parent=self.root)
        else:
            try:
                conn=mysql.connector.connect(
                   host="localhost"
                   ,user="root",
                   password="W7301@jqir*",
                   database="sql_workbench")
                my_cursor=conn.cursor()
                my_cursor.execute("insert into details values(%s,%s,%s)", (
                                                          self.var_floor.get(),
                                                            self.var_roomno.get(),
                                                          self.var_roomtype.get() ))

                conn.commit()
                self.fetch_data()
                conn.close()
                messagebox.showinfo("Success!!", "New Room Added😊 ",parent=self.root)
            except Exception as es:
                messagebox.showwarning("Warning ##",f"Something went wrong:{str(es)}",parent=self.root)

    def fetch_data(self):
        conn = mysql.connector.connect(host="localhost",user="root",password="W7301@jqir*",database="sql_workbench")
        my_cursor = conn.cursor()
        my_cursor.execute("select * from details")
        rows=my_cursor.fetchall()
        if len(rows)!=0:
           self.room_table.delete(*self.room_table.get_children())
           for i in rows:
               self.room_table.insert("",END,values=i)
           conn.commit()
        conn.close()

    def get_cursor(self,event=""):
        cursor_row=self.room_table.focus()
        conteent=self.room_table.item(cursor_row)
        row=conteent["values"]

        self.var_floor.set(row[0]),
        self.var_roomno.set(row[1]),
        self.var_roomtype.set(row[2])
        # next step is always bind it -line105

        # ============= update function==============================
    def update_data(self):
            if self.var_floor == "":
                messagebox.showerror("Error", "Please, first enter mobile number", parent=self.root)
            else:
                conn = mysql.connector.connect(host="localhost", user="root", password="W7301@jqir*",
                                               database="sql_workbench")
                my_cursor = conn.cursor()
                my_cursor.execute(
                    "update details set Floor=%s,RoomType=%s where RoomNo=%s",
                    (
                        self.var_floor.get(),
                        self.var_roomtype.get(),
                        self.var_roomno.get() ))
                conn.commit()
                self.fetch_data()
                conn.close()
                messagebox.showinfo("Success", "Room details has been updated 🙌", parent=self.root)

 # -=========================Delete functionalities======================
    def mdelete(self):
        mdelete = messagebox.askyesno("HMS", "Do you want to delete this Room", parent=self.root)
        if mdelete > 0:
            conn = mysql.connector.connect(host="localhost", user="root", password="W7301@jqir*",
                                           database="sql_workbench")
            my_cursor = conn.cursor()
            query = "delete from details where RoomNo=%s"
            value = (self.var_roomno.get(),)
            my_cursor.execute(query, value)
        else:
            if not mdelete:
                return
        conn.commit()
        self.fetch_data()
        conn.close()

        # reset function=============================================
    def reset(self):
            self.var_floor.set("")
            self.var_roomno.set("")
            self.var_roomtype.set("")


if __name__ == '__main__':
    root=Tk()
    obj=DetailsRooms(root)
    root.mainloop()