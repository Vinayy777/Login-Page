from tkinter import *
from PIL import Image,ImageTk
from tkinter import ttk
import mysql.connector
import random
from tkinter import messagebox




class Cust_win:
    def __init__(self,root):
        self.root=root
        self.root.title("Hotel Management System ")
        self.root.geometry("1120x510+230+180")
#======================== Variable=========================================
        self.var_ref=StringVar()
        x=random.randint(1000,9999)
        self.var_ref.set(str(x))

        self.var_cust_name=StringVar()
        self.var_mother=StringVar()
        self.var_gender=StringVar()
        self.var_post = StringVar()
        self.var_mobile = StringVar()
        self.var_email = StringVar()
        self.var_nationality = StringVar()
        self.var_id_proof = StringVar()
        self.var_id_number = StringVar()
        self.var_address=StringVar()


        lbl_title = Label(self.root, text="ADD CUSTOMER DETAILS", font=("times new roman", 18, "bold"), bg="black", fg="gold", relief=RIDGE, bd=4)
        lbl_title.place(x=0, y=0, width=1120, height=50)

        Img2 = Image.open( r"C:\Users\ABC\PycharmProjects\HotelManagementSystem\images\hotel images\logohotel.png")
        Img2 = Img2.resize((100, 40), Image.BILINEAR)
        self.photoImg2 = ImageTk.PhotoImage(Img2)

        lblimg = Label(self.root, image=self.photoImg2, bd=0, relief=RIDGE)
        lblimg.place(x=5, y=2, width=100, height=40)

        #===================== Label frame=================
        labelframeleft=LabelFrame(self.root,bd=2,relief=RIDGE,bg="#751aff",text="Customer details",font=("times new roman", 12, "bold"),padx=2)
        labelframeleft.place(x=5,y=50,width=400,height=450)

        #cust_ref
        lbl_cust_ref=Label(labelframeleft,text="CUSTOMER REF",font=("times new roman", 11, "bold"),padx=2,pady=6,bg="#751aff")
        lbl_cust_ref.grid(row=0,column=0,sticky=W)

        entry_ref=ttk.Entry(labelframeleft,textvariable=self.var_ref,width=25,font=("arial", 12, "bold"),state="readonly")
        entry_ref.grid(row=0,column=1)

        # cust_name
        cust_nm = Label(labelframeleft, text="CUSTOMER NAME", font=("times new roman", 11, "bold"), padx=2, pady=6,bg="#751aff")
        cust_nm.grid(row=1, column=0, sticky=W)

        entry_nm = ttk.Entry(labelframeleft,textvariable=self.var_cust_name, width=25, font=("arial", 12, "bold"), )
        entry_nm.grid(row=1, column=1)

        # mother name
        lbl_cust_mn = Label(labelframeleft, text="MOTHER NAME", font=("times new roman", 11, "bold"), padx=2, pady=6,bg="#751aff")
        lbl_cust_mn.grid(row=2, column=0, sticky=W)

        entry_mn = ttk.Entry(labelframeleft, textvariable=self.var_mother,width=25, font=("arial", 12, "bold"), )
        entry_mn.grid(row=2, column=1)

        # gender combobox
        lbl_cust_gen = Label(labelframeleft, text="GENDER", font=("times new roman", 11, "bold"), padx=2, pady=6,bg="#751aff")
        lbl_cust_gen.grid(row=3, column=0, sticky=W)

        combo_gen=ttk.Combobox(labelframeleft, textvariable=self.var_gender,width=23, font=("arial",12,"bold"), state="readonly")
        combo_gen["values"]=("Male","Female","Other")
        combo_gen.current(0)
        combo_gen.grid(row=3,column=1)


        # post code
        lbl_cust_pc = Label(labelframeleft, text="POST CODE", font=("times new roman", 11, "bold"), padx=2, pady=6,bg="#751aff")
        lbl_cust_pc.grid(row=4, column=0, sticky=W)

        entry_pc = ttk.Entry(labelframeleft,textvariable=self.var_post, width=25, font=("arial", 12, "bold"), )
        entry_pc.grid(row=4, column=1)

        # Mobile no
        lbl_cust_mob = Label(labelframeleft, text="MOBILE", font=("times new roman", 11, "bold"), padx=2, pady=6,bg="#751aff")
        lbl_cust_mob.grid(row=5, column=0, sticky=W)

        entry_mob = ttk.Entry(labelframeleft, textvariable=self.var_mobile,width=25, font=("arial", 12, "bold"), )
        entry_mob.grid(row=5, column=1)

        # Email
        lbl_cust_eml = Label(labelframeleft,text="EMAIL", font=("arial", 11, "bold"), padx=2, pady=6,bg="#751aff")
        lbl_cust_eml.grid(row=6, column=0, sticky=W)

        entry_eml = ttk.Entry(labelframeleft,textvariable=self.var_email , width=25, font=("arial", 12, "bold"), )
        entry_eml.grid(row=6, column=1)

        # Nationality
        lbl_cust_na = Label(labelframeleft, text="NATIONALITY", font=("times new roman", 11, "bold"), padx=2, pady=6,bg="#751aff")
        lbl_cust_na.grid(row=7, column=0, sticky=W)

        combo_na = ttk.Combobox(labelframeleft,textvariable=self.var_nationality ,width=23, font=("arial", 12, "bold"), state="readonly")
        combo_na["values"] = ("INDIA", "AMERICA", "ENGLAND")
        combo_na.current(0)
        combo_na.grid(row=7, column=1)

        # Id proof type COMBO
        lbl_cust_id = Label(labelframeleft, text="ID PROOF TYPE", font=("times new roman", 11, "bold"), padx=2, pady=6,bg="#751aff")
        lbl_cust_id.grid(row=8, column=0, sticky=W)


        combo_id = ttk.Combobox(labelframeleft,textvariable=self.var_id_proof, width=23, font=("arial", 12, "bold"), state="readonly")
        combo_id["values"] = ("ADHAR CARD", "DRIVING LICENCE", "PASSPORT")
        combo_id.current(0)
        combo_id.grid(row=8, column=1)

        # Id no
        lbl_cust_idno = Label(labelframeleft, text="ID NUMBER", font=("arial", 11, "bold"), padx=2, pady=6,bg="#751aff")
        lbl_cust_idno.grid(row=9, column=0, sticky=W)

        entry_idno = ttk.Entry(labelframeleft,textvariable=self.var_id_number, width=25, font=("arial", 12, "bold"), )
        entry_idno.grid(row=9, column=1)

        # Address
        lbl_cust_ad = Label(labelframeleft, text="ADDRESS", font=("arial", 11, "bold"), padx=2, pady=6,bg="#751aff")
        lbl_cust_ad.grid(row=10, column=0, sticky=W)

        entry_ad = ttk.Entry(labelframeleft,textvariable=self.var_address, width=25, font=("arial", 12, "bold"), )
        entry_ad.grid(row=10, column=1)

        #===========================BTN=================================
        btn_frame=Frame(labelframeleft,bd=2,relief=RIDGE)
        btn_frame.place(x=20,y=380,width=350,height=36)

        add_btn=Button(btn_frame,text="ADD",command=self.add_data,font=("arial", 13, "bold"),bg="black",fg="gold",width=8)
        add_btn.grid(row=0,column=0,padx=1)

        update_btn = Button(btn_frame, text="UPDATE",command=self.update_data ,font=("arial", 13, "bold"), bg="black", fg="gold", width=8)
        update_btn.grid(row=0, column=1, padx=1)

        delete_btn = Button(btn_frame, text="DELETE",command=self.mdelete,font=("arial", 13, "bold"), bg="black", fg="gold", width=7)
        delete_btn.grid(row=0, column=2, padx=1)

        reset_btn = Button(btn_frame, text="RESET",command=self.reset, font=("arial", 13, "bold"), bg="black", fg="gold", width=7)
        reset_btn.grid(row=0, column=3, padx=1)

        # ===================== tabely frame search system=================
        tabelframe  = LabelFrame(self.root, bd=2, relief=RIDGE, text="View details and search system",font=("times new roman", 12, "bold"), padx=2)
        tabelframe.place(x=400, y=50, width=710, height=450)

        lbl_search = Label(tabelframe, text="SEARCH BY", font=("arial", 12, "bold"),bg="red",fg="white" )
        lbl_search.grid(row=0, column=0, sticky=W,padx=2)

        self.search_var=StringVar()
        combo_search = ttk.Combobox( tabelframe,textvariable=self.search_var, width=15, font=("arial", 13, "bold"), state="readonly")
        combo_search["values"] = ("MOBILE NO", "REF")
        combo_search.current(0)
        combo_search.grid(row=0, column=1,padx=2,sticky=W)

        self.text_search=StringVar()
        txt_search = ttk.Entry(tabelframe,textvariable=self.text_search ,width=17, font=("arial", 13, "bold") )
        txt_search.grid(row=0, column=2,padx=2)

        btnsearch = Button(tabelframe, text="SEARCH",command=self.search ,font=("arial", 13, "bold"), bg="black", fg="gold", width=12)
        btnsearch.grid(row=0, column=3, padx=1)

        btnShowAll = Button(tabelframe, text="SHOW ALL",command=self.fetch_data, font=("arial", 13, "bold"), bg="black", fg="gold", width=12)
        btnShowAll.grid(row=0, column=4, padx=1)

        # ===========================Show data table =================================
        details_table = Frame(tabelframe , bd=2, relief=RIDGE)
        details_table.place(x=0, y=35, width=700, height=350)

        scroll_x=ttk.Scrollbar(details_table,orient=HORIZONTAL)
        scroll_y=ttk.Scrollbar(details_table, orient=VERTICAL)

        self.cust_details_view=ttk.Treeview(details_table,columns=("ref",'name','mother','gender',
                                              'post','mobile','email','nationality','idproof','idno'
                                            ,'adress'),xscrollcommand=scroll_x,yscrollcommand=scroll_y)

        scroll_x.pack(side=BOTTOM,fill=X)
        scroll_y.pack(side=RIGHT,fill=Y)

        scroll_x.config(command=self.cust_details_view.xview)
        scroll_y.config(command=self.cust_details_view.yview)

        self.cust_details_view.heading("ref",text="Refer No")
        self.cust_details_view.heading("name", text="Name")
        self.cust_details_view.heading("mother", text="Mother Name")
        self.cust_details_view.heading("gender", text="Gender")
        self.cust_details_view.heading("post", text="PostCode")
        self.cust_details_view.heading("mobile", text="Mobile")
        self.cust_details_view.heading("email", text="Email")
        self.cust_details_view.heading("nationality", text="Nationality")
        self.cust_details_view.heading("idproof", text="IdProof")
        self.cust_details_view.heading("idno", text="ID No")
        self.cust_details_view.heading("adress", text="Adress")

        self.cust_details_view["show"]="headings"

        self.cust_details_view.column("ref",width=55)
        self.cust_details_view.column("name", width=90)
        self.cust_details_view.column("mother", width=85)
        self.cust_details_view.column("gender", width=50)
        self.cust_details_view.column("post", width=60)
        self.cust_details_view.column("mobile", width=70)
        self.cust_details_view.column("email", width=80)
        self.cust_details_view.column("nationality", width=75)
        self.cust_details_view.column("idproof", width=85)
        self.cust_details_view.column("idno", width=100)
        self.cust_details_view.column("adress", width=80)

        self.cust_details_view.pack(fill=BOTH,expand=1)
        self.cust_details_view.bind("<ButtonRelease-1>",self.get_cursor)
        self.fetch_data()
# add funtionalities
    def add_data(self):
        if self.var_mobile.get()=="" or self.var_mother.get()=="" :
            messagebox.showerror("Error ", "Don't leave any fields ",parent=self.root)
        else:
            try:
                conn=mysql.connector.connect(
                    host="localhost"
                    ,user="root",
                    password="W7301@jqir*",
                    database="sql_workbench")
                my_cursor=conn.cursor()
                my_cursor.execute("insert into customer values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)", (
               self.var_ref.get(),
                self.var_cust_name.get(),
                self.var_mother.get(),
                self.var_gender.get(),
                self.var_post.get(),
                self.var_mobile.get(),
                self.var_email.get(),
                self.var_nationality.get(),
                self.var_id_proof.get(),
                self.var_id_number.get(),
                self.var_address.get() ))
                conn.commit()
                self.fetch_data()
                conn.close()
                messagebox.showinfo("Success!!" "user has been added ",parent=self.root)
            except Exception as es:
                messagebox.showwarning("Warning ##",f"Something went wrong:{str(es)}",parent=self.root)

    def fetch_data(self):
        conn = mysql.connector.connect(
            host="localhost"
            , user="root",
            password="W7301@jqir*",
            database="sql_workbench")
        my_cursor = conn.cursor()
        my_cursor.execute("select * from customer")
        rows=my_cursor.fetchall()
        if len(rows)!=0:
           self.cust_details_view.delete(*self.cust_details_view.get_children())
           for i in rows:
               self.cust_details_view.insert("",END,values=i)
           conn.commit()
        conn.close()

    def get_cursor(self,event=""):
        cursor_row=self.cust_details_view.focus()
        conteent=self.cust_details_view.item(cursor_row)
        row=conteent["values"]

        self.var_ref.set(row[0]),
        self.var_cust_name.set(row[1])
        self.var_mother.set(row[2]),
        self.var_gender.set(row[3]),
        self.var_post.set(row[4]),
        self.var_mobile.set(row[5]),
        self.var_email.set(row[6]),
        self.var_nationality.set(row[7]),
        self.var_id_proof.set(row[8]),
        self.var_id_number.set(row[9]),
        self.var_address.set(row[10])

#==============Update function=======================
    def update_data(self):
        if self.var_mobile=="":
            messagebox.showerror("Error","Please, first enter mobile number",parent=self.root)
        else:
            conn = mysql.connector.connect(host="localhost",user="root",password="W7301@jqir*",database="sql_workbench")
            my_cursor = conn.cursor()
            my_cursor.execute("update customer set Name=%s,Mother=%s,Gender=%s,Postcode=%s,Mobile=%s,Email=%s,Nationality=%s,Idproof=%s,Idnumber=%s,Address=%s where Ref=%s",(

                                                                                                self.var_cust_name.get(),
                                                                                                self.var_mother.get(),
                                                                                                self.var_gender.get(),
                                                                                                self.var_post.get(),
                                                                                                self.var_mobile.get(),
                                                                                                self.var_email.get(),
                                                                                                self.var_nationality.get(),
                                                                                                self.var_id_proof.get(),
                                                                                                self.var_id_number.get(),
                                                                                                self.var_address.get(),
                                                                                                self.var_ref.get()

                          ))
            conn.commit()
            self.fetch_data()
            conn.close()
            messagebox.showinfo("Success","Customer details has been updated",parent=self.root)


    #-=========================Delete functionalities======================
    def mdelete(self):
        mdelete=messagebox.askyesno("HMS","Do you want to delete this customer details",parent=self.root)
        if mdelete>0:
            conn=mysql.connector.connect(host="localhost",user="root",password="W7301@jqir*",database="sql_workbench")
            my_cursor = conn.cursor()
            query="delete from customer where Ref=%s"
            value=(self.var_ref.get(),)
            my_cursor.execute(query,value)
        else:
            if not mdelete:
                return
        conn.commit()
        self.fetch_data()
        conn.close()

    # reset function==================================
    def reset(self):
        #self.var_ref.set(""),
        self.var_cust_name.set( "")
        self.var_mother.set( ""),
        #self.var_gender.set( ""),
        self.var_post.set( ""),
        self.var_mobile.set( ""),
        self.var_email.set(" "),
        #self.var_nationality.set(" "),
        #self.var_id_proof.set( ""),
        self.var_id_number.set(" "),
        self.var_address.set(" ")

        x = random.randint(1000, 9999)
        self.var_ref.set(str(x))

    def search(self):
        conn = mysql.connector.connect(host="localhost", user="root", password="W7301@jqir*", database="sql_workbench")
        my_cursor = conn.cursor()

        my_cursor.execute("select * from customer where "+str(self.search_var.get())+" LIKE '%"+str(self.text_search.get())+"%'")
        rows=my_cursor.fetchall()
        if len(rows)!=0:
            self.cust_details_view.delete(*self.cust_details_view.get_children())
            for i in rows:
                self.cust_details_view.insert("",END,values=i)
            conn.commit()
        conn.close()

if __name__=="__main__":
    root=Tk()
    obj=Cust_win(root)
    root.mainloop()
