from tkinter import *
from PIL import Image,ImageTk
from tkinter import ttk
import mysql.connector
from time import strftime
from  datetime import  datetime
import random
from tkinter import messagebox




class Room_booking:
    def __init__(self,root):
        self.root=root
        self.root.title("Hotel Management System ")
        self.root.geometry("1120x510+230+180")

        #=============== variables-=======================
        self.var_contact=StringVar()
        self.var_checkin=StringVar()
        self.var_checkout = StringVar()
        self.var_roomtype = StringVar()
        self.var_roomavailable = StringVar()
        self.var_meal = StringVar()
        self.var_noOfdays = StringVar()
        self.var_paidtax = StringVar()
        self.var_actualtotal = StringVar()
        self.var_total = StringVar()

        lbl_title = Label(self.root, text="ROOM BOOKINGS", font=("times new roman", 18, "bold"), bg="black", fg="gold", relief=RIDGE, bd=4)
        lbl_title.place(x=0, y=0, width=1235, height=50)

        Img2 = Image.open(r"C:\Users\ABC\PycharmProjects\HotelManagementSystem\images\hotel images\logohotel.png")
        Img2 = Img2.resize((100, 40), Image.BILINEAR)
        self.photoImg2 = ImageTk.PhotoImage(Img2)

        lblimg = Label(self.root, image=self.photoImg2, bd=0, relief=RIDGE)
        lblimg.place(x=5, y=2, width=100, height=40)

        # ===================== Label frame=================
        labelframeleft = LabelFrame(self.root, bd=2, relief=RIDGE, text="Room Booking Details",font=("times new roman", 12, "bold"),bg="#ff0066", padx=2)
        labelframeleft.place(x=5, y=50, width=430, height=450)

        # cust_contaict
        lbl_cust_contaict = Label(labelframeleft, text="CUSTOMER CONTACT", font=("times new roman", 12, "bold"), padx=2, pady=6,bg="#ff0066")
        lbl_cust_contaict.grid(row=0, column=0, sticky='ew')

        entry_contaict = ttk.Entry(labelframeleft,textvariable=self.var_contact, width=18, font=("arial", 13, "bold"))
        entry_contaict.grid(row=0, column=1,sticky=W)

        #fetch data button
        fetch_btn = Button(labelframeleft,command=self.fetch_contact,relief=RIDGE, text="FETCH" , font=("arial", 13, "bold"), bg="black",fg="gold", width=5)
        fetch_btn.place(x=360,y=4)

        # check in date
        chk_in_dt = Label(labelframeleft, text="CHECK IN DATE", font=("times new roman", 12, "bold"),padx=2, pady=6,bg="#ff0066")
        chk_in_dt.grid(row=1, column=0, sticky=W)

        entry_chk_in = ttk.Entry(labelframeleft, textvariable=self.var_checkin,width=25, font=("arial", 13, "bold"))
        entry_chk_in.grid(row=1, column=1)

        # check out date
        chk_out_dt = Label(labelframeleft, text="CHECK OUT DATE", font=("times new roman", 12, "bold"), padx=2, pady=6,bg="#ff0066")
        chk_out_dt.grid(row=2, column=0, sticky=W)

        entry_chk_out = ttk.Entry(labelframeleft, textvariable=self.var_checkout,width=25, font=("arial", 13, "bold"))
        entry_chk_out.grid(row=2, column=1)

        # room type
        lbl_roomtype = Label(labelframeleft, text="ROOM TYPE", font=("times new roman", 12, "bold"), padx=2, pady=6,bg="#ff0066")
        lbl_roomtype.grid(row=3, column=0, sticky=W)

        conn = mysql.connector.connect(host="localhost", user="root", password="W7301@jqir*", database="sql_workbench")
        my_cursor = conn.cursor()
        my_cursor.execute("select RoomType from details")
        id = my_cursor.fetchall()

        combo_roontype =ttk.Combobox(labelframeleft,textvariable=self.var_roomtype ,width=23, font=("arial", 13, "bold"),state="readonly")
        combo_roontype["values"] = id
        combo_roontype.current(0)
        combo_roontype.grid(row=3, column=1)

        # room availability
        lbl_room_avail = Label(labelframeleft, text="AVAILABLE ROOM", font=("times new roman", 12, "bold"), padx=2, pady=6,bg="#ff0066")
        lbl_room_avail.grid(row=4, column=0, sticky=W)

        #txt_avail = ttk.Entry(labelframeleft,textvariable=self.var_roomavailable ,width=25, font=("arial", 13, "bold"), )
        #txt_avail.grid(row=4, column=1)
        conn = mysql.connector.connect(host="localhost", user="root", password="W7301@jqir*", database="sql_workbench")
        my_cursor = conn.cursor()
        my_cursor.execute("select RoomNo from details")
        rows = my_cursor.fetchall()

        combo_roomno = ttk.Combobox(labelframeleft, textvariable=self.var_roomavailable, width=23,font=("arial", 13, "bold"), state="readonly")
        combo_roomno["values"] = rows
        combo_roomno.current(0)
        combo_roomno.grid(row=4, column=1)

        # meal
        lbl_meal = Label(labelframeleft, text="MEAL", font=("times new roman", 12, "bold"), padx=2,pady=6, bg="#ff0066")
        lbl_meal.grid(row=5, column=0, sticky=W)

        txt_meal = ttk.Entry(labelframeleft,textvariable=self.var_meal ,width=25, font=("arial", 13, "bold"), )
        txt_meal.grid(row=5, column=1)

        # no of days
        lbl_no_days = Label(labelframeleft, text="NO OF DAYS", font=("times new roman", 12, "bold"), padx=2, pady=6, bg="#ff0066")
        lbl_no_days.grid(row=6, column=0, sticky=W)

        txt_nodays = ttk.Entry(labelframeleft, textvariable=self.var_noOfdays,width=25, font=("arial", 13, "bold"), )
        txt_nodays.grid(row=6, column=1)

        # paid tax
        lbl_tax = Label(labelframeleft, text="PAID TAX", font=("times new roman", 12, "bold"), padx=2, pady=6, bg="#ff0066")
        lbl_tax.grid(row=7, column=0, sticky=W)

        txt_tax = ttk.Entry(labelframeleft,textvariable=self.var_paidtax ,width=25, font=("arial", 13, "bold"), )
        txt_tax.grid(row=7, column=1)

        # subtotal
        lbl_subtotal = Label(labelframeleft, text="SUB TOTAL", font=("times new roman", 12, "bold"), padx=2, pady=6, bg="#ff0066")
        lbl_subtotal.grid(row=8, column=0, sticky=W)

        txt_subtotal = ttk.Entry(labelframeleft, textvariable=self.var_actualtotal,width=25, font=("arial", 13, "bold"), )
        txt_subtotal.grid(row=8, column=1)

        # total cost
        lbl_cost = Label(labelframeleft, text="TOTAL AMOUNT", font=("times new roman", 12, "bold"), padx=2, pady=6, bg="#ff0066")
        lbl_cost.grid(row=9, column=0, sticky=W)

        txt_cost = ttk.Entry(labelframeleft, textvariable=self.var_total,width=25, font=("arial", 13, "bold"), )
        txt_cost.grid(row=9, column=1)

        #-----------------bill bitton-----------------------------
        add_bill = Button(labelframeleft,command=self.total,bd=2,relief=RIDGE,text="BILL", font=("arial", 13, "bold"), bg="black", fg="gold", width=5)
        add_bill.grid(row=10, column=0, padx=2,sticky=W)
        add_bill.place(x=20,y=345, width=45, height=36)

        # ===========================BTN=================================
        btn_frame = Frame(labelframeleft, bd=2, relief=RIDGE)
        btn_frame.place(x=20, y=385, width=350, height=36)

        add_btn = Button(btn_frame, text="ADD",command=self.Add_data,font=("arial", 13, "bold"), bg="black",   fg="gold", width=8)
        add_btn.grid(row=0, column=0, padx=1)

        update_btn = Button(btn_frame,command=self.update_data,text="UPDATE",font=("arial", 13, "bold"), bg="black",  fg="gold", width=8)
        update_btn.grid(row=0, column=1, padx=1)

        delete_btn = Button(btn_frame,command=self.mdelete,text="DELETE",font=("arial", 13, "bold"), bg="black",fg="gold", width=7)
        delete_btn.grid(row=0, column=2, padx=1)

        reset_btn = Button(btn_frame,command=self.reset,text="RESET", font=("arial", 13, "bold"), bg="black",fg="gold", width=7)
        reset_btn.grid(row=0, column=3, padx=1)

        #================right side image===============================
        Img4 = Image.open( r"C:\Users\ABC\PycharmProjects\HotelManagementSystem\images\hotel images\bed.jpg")
        Img4 = Img4.resize((360, 225), Image.BILINEAR)
        self.photoImg4 = ImageTk.PhotoImage(Img4)
        lblimg = Label(self.root,image=self.photoImg4,bd=0,relief=RIDGE)
        lblimg.place(x=750,y=55,width=360,height=225)

        # ===================== tabel frame search system=================
        tabelframe = LabelFrame(self.root, bd=2,relief=RIDGE,text="View details and search system", font=("times new roman", 12, "bold"), padx=2)
        tabelframe.place(x=440,y=280,width=670,height=215)

        lbl_search = Label(tabelframe, text="SEARCH BY", font=("arial", 12, "bold"), bg="red", fg="white")
        lbl_search.grid(row=0,column=0,sticky=W,padx=2)

        self.search_var = StringVar()
        combo_search = ttk.Combobox(tabelframe,textvariable=self.search_var, width=15, font=("arial", 13, "bold"),state="readonly")
        combo_search["values"] = ("CONTACT", "ROOM")
        combo_search.current(0)
        combo_search.grid(row=0,column=1,padx=2,sticky=W)

        self.text_search = StringVar()
        txt_search = ttk.Entry(tabelframe,textvariable=self.text_search, width=17, font=("arial", 13, "bold"))
        txt_search.grid(row=0,column=2,padx=2)

        btnsearch = Button(tabelframe,command=self.search,text="SEARCH",font=("arial", 10, "bold"), bg="black",fg="gold", width=8)
        btnsearch.grid(row=0,column=3,padx=1)

        btnShowAll = Button(tabelframe,command=self.fetch_data ,text="SHOW ALL", font=("arial", 10, "bold"),bg="black", fg="gold", width=10)
        btnShowAll.grid(row=0,column=4,padx=1)

        # ===========================Show data table =================================

        details_table = Frame(tabelframe, bd=2, relief=RIDGE)
        details_table.place(x=0, y=35, width=670, height=150)

        scroll_x = ttk.Scrollbar(details_table, orient=HORIZONTAL)
        scroll_y = ttk.Scrollbar(details_table, orient=VERTICAL)

        self.room_table = ttk.Treeview(details_table, columns=("contact", 'checkin', 'checkout', 'roomtype',
                                                                      'roomavailable', 'meal', 'noOfdays',), xscrollcommand=scroll_x,
                                                                                                             yscrollcommand=scroll_y)

        scroll_x.pack(side=BOTTOM, fill=X)
        scroll_y.pack(side=RIGHT, fill=Y)

        scroll_x.config(command=self.room_table.xview)
        scroll_y.config(command=self.room_table.yview)

        self.room_table.heading("contact", text="Contact")
        self.room_table.heading("checkin", text="Check-In")
        self.room_table.heading("checkout", text="Check Out")
        self.room_table.heading("roomtype", text="Room Type")
        self.room_table.heading("roomavailable", text="Room No")
        self.room_table.heading("meal", text="Meal")
        self.room_table.heading("noOfdays", text="NoOfDays")

        self.room_table["show"] = "headings"

        self.room_table.column("contact", width=55)
        self.room_table.column("checkin", width=90)
        self.room_table.column("checkout", width=85)
        self.room_table.column("roomtype", width=50)
        self.room_table.column("roomavailable", width=60)
        self.room_table.column("meal", width=70)
        self.room_table.column("noOfdays", width=80)
        self.room_table.pack(fill=BOTH, expand=1)

        self.room_table.bind("<ButtonRelease-1>", self.get_cursor)
        self.fetch_data()

    def Add_data(self):
        if self.var_contact.get()=="" or self.var_checkin.get()=="" :
            messagebox.showerror("Error ", "Don't leave any fields ",parent=self.root)
        else:
            try:
                conn=mysql.connector.connect(
                   host="localhost"
                   ,user="root",
                   password="W7301@jqir*",
                   database="sql_workbench")
                my_cursor=conn.cursor()
                my_cursor.execute("insert into room values(%s,%s,%s,%s,%s,%s,%s)", (
                                                            self.var_contact.get(),
                                                            self.var_checkin.get(),
                                                            self.var_checkout.get(),
                                                            self.var_roomtype.get(),
                                                            self.var_roomavailable.get(),
                                                            self.var_meal.get(),
                                                            self.var_noOfdays.get()))
                conn.commit()
                self.fetch_data()
                conn.close()
                messagebox.showinfo("Success!!", "Room booked😊 ",parent=self.root)
            except Exception as es:
                messagebox.showwarning("Warning ##",f"Something went wrong:{str(es)}",parent=self.root)

    # ======================= fetching data oa page=========================
    def fetch_data(self):
        conn = mysql.connector.connect(host="localhost",user="root",password="W7301@jqir*",database="sql_workbench")
        my_cursor = conn.cursor()
        my_cursor.execute("select * from room")
        rows=my_cursor.fetchall()
        if len(rows)!=0:
           self.room_table.delete(*self.room_table.get_children())
           for i in rows:
               self.room_table.insert("",END,values=i)
           conn.commit()
        conn.close()

    #======================== getting all data on entry fill=================================
    def get_cursor(self,event=""):
        cursor_row=self.room_table.focus()
        conteent=self.room_table.item(cursor_row)
        row=conteent["values"]

        self.var_contact.set(row[0]),
        self.var_checkin.set(row[1]),
        self.var_checkout.set(row[2]),
        self.var_roomtype.set(row[3]),
        self.var_roomavailable.set(row[4]),
        self.var_meal.set(row[5]),
        self.var_noOfdays.set(row[6])
        # next step is always bind it -line209

    # ============= update function==============================
    def update_data(self):
        if self.var_contact=="":
            messagebox.showerror("Error","Please, first enter mobile number",parent=self.root)
        else:
            conn = mysql.connector.connect(host="localhost",user="root",password="W7301@jqir*",database="sql_workbench")
            my_cursor = conn.cursor()
            my_cursor.execute("update room set check_in=%s,check_out=%s,roomtype=%s,roomavailable=%s,meal=%s,noOfdays=%s where Contact=%s",(
                self.var_checkin.get(),
                self.var_checkout.get(),
                self.var_roomtype.get(),
                self.var_roomavailable.get(),
                self.var_meal.get(),
                self.var_noOfdays.get(),
                self.var_contact.get() ))
            conn.commit()
            self.fetch_data()
            conn.close()
            messagebox.showinfo("Success","Room details has been updated 🙌",parent=self.root)

        # -=========================Delete functionalities======================
    def mdelete(self):
            mdelete = messagebox.askyesno("HMS", "Do you want to delete this customer details", parent=self.root)
            if mdelete > 0:
                conn = mysql.connector.connect(host="localhost", user="root", password="W7301@jqir*", database="sql_workbench")
                my_cursor = conn.cursor()
                query = "delete from room where Contact=%s"
                value = (self.var_contact.get(),)
                my_cursor.execute(query, value)
            else:
                if not mdelete:
                    return
            conn.commit()
            self.fetch_data()
            conn.close()

    # reset function=============================================
    def reset(self):
        self.var_contact.set("")
        self.var_checkin.set("")
        self.var_checkout.set("")
        self.var_roomtype.set("")
        self.var_roomavailable.set("")
        self.var_meal.set("")
        self.var_noOfdays.set("")
        self.var_paidtax.set("")
        self.var_actualtotal.set("")
        self.var_total.set("")

    #================all contact fetch==========================
    def fetch_contact(self):
        if self.var_contact.get()=="":
            messagebox.showerror("Error","Plz! enter contact number",parent=self.root)
        else:
            conn = mysql.connector.connect(host="localhost", user="root", password="W7301@jqir*", database="sql_workbench")
            my_cursor = conn.cursor()
            query=("select Name from customer where Mobile=%s")
            value=(self.var_contact.get(),)
            my_cursor.execute(query,value)
            row=my_cursor.fetchone()
            if row==None:
                messagebox.showerror("Error","This no not found",parent=self.root)
            else:
                conn.commit()
                conn.close()

                showdata_frame=Frame(self.root,bd=4,relief=RIDGE,padx=2)
                showdata_frame.place(x=440,y=55,width=305,height=225)

                lbl_name=Label(showdata_frame,text="Name: ",font=("arial",12,"bold"))
                lbl_name.place(x=0,y=0)

                lbl=Label(showdata_frame,text=row,font=("arial",12,"bold"))
                lbl.place(x=70, y=0)

                #================gender===============
                conn = mysql.connector.connect(host="localhost", user="root", password="W7301@jqir*",  database="sql_workbench")
                my_cursor = conn.cursor()
                query = ("select Gender from customer where Mobile=%s")
                value = (self.var_contact.get(),)
                my_cursor.execute(query, value)
                row = my_cursor.fetchone()

                lbl_gender = Label(showdata_frame, text="Gender: ", font=("arial", 12, "bold"))
                lbl_gender.place(x=0, y=30)

                lbl2 = Label(showdata_frame, text=row, font=("arial", 12, "bold"))
                lbl2.place(x=70, y=30)

                # ================email===============
                conn = mysql.connector.connect(host="localhost", user="root", password="W7301@jqir*",
                                               database="sql_workbench")
                my_cursor = conn.cursor()
                query = ("select Email from customer where Mobile=%s")
                value = (self.var_contact.get(),)
                my_cursor.execute(query, value)
                row = my_cursor.fetchone()

                lbl_email = Label(showdata_frame, text="Email: ", font=("arial", 12, "bold"))
                lbl_email.place(x=0, y=60)

                lbl3 = Label(showdata_frame, text=row, font=("arial", 12, "bold"))
                lbl3.place(x=70, y=60)

                # ================nationality===============
                conn = mysql.connector.connect(host="localhost", user="root", password="W7301@jqir*",
                                               database="sql_workbench")
                my_cursor = conn.cursor()
                query = ("select Nationality from customer where Mobile=%s")
                value = (self.var_contact.get(),)
                my_cursor.execute(query, value)
                row = my_cursor.fetchone()

                lbl_nation = Label(showdata_frame, text="Nationality:", font=("arial", 12, "bold"))
                lbl_nation.place(x=0, y=90)

                lbl4 = Label(showdata_frame, text=row, font=("arial", 12, "bold"))
                lbl4.place(x=90, y=90)

                # ================address===============
                conn = mysql.connector.connect(host="localhost", user="root", password="W7301@jqir*",
                                               database="sql_workbench")
                my_cursor = conn.cursor()
                query = ("select Address from customer where Mobile=%s")
                value = (self.var_contact.get(),)
                my_cursor.execute(query, value)
                row = my_cursor.fetchone()

                lbl_address = Label(showdata_frame, text="Address: ", font=("arial", 12, "bold"))
                lbl_address.place(x=0, y=120)

                lbl5 = Label(showdata_frame, text=row, font=("arial", 12, "bold"))
                lbl5.place(x=70, y=120)

    '''def total(self):
        indate=self.var_checkin.get()
        outdate=self.var_checkout.get()
        indate=datetime.strptime(indate,'%d/%m/%y')
        outdate = datetime.strptime(outdate, '%d/%m/%y')
        self.var_noOfdays.set(abs(outdate-indate).days)'''

    #search system
    def search(self):
        conn = mysql.connector.connect(host="localhost", user="root", password="W7301@jqir*", database="sql_workbench")
        my_cursor = conn.cursor()

        my_cursor.execute("select * from room where "+str(self.search_var.get())+" LIKE '%"+str(self.text_search.get())+"%'")
        rows=my_cursor.fetchall()
        if len(rows)!=0:
            self.room_table.delete(*self.room_table.get_children())
            for i in rows:
                self.room_table.insert("",END,values=i)
            conn.commit()
        conn.close()



    # helped by chatdpt
    # total function

    def total(self):
        indate = self.var_checkin.get()
        outdate = self.var_checkout.get()

        # Parse the input date strings
        indate = datetime.strptime(indate, '%d/%m/%y')
        outdate = datetime.strptime(outdate, '%d/%m/%y')

        # Calculate the difference in days
        no_of_days = abs((outdate - indate).days)

        # Set the calculated number of days to a variable
        self.var_noOfdays.set(no_of_days)

        if (self.var_meal.get()=="Dinner" and self.var_roomtype.get()=="Double"):
            q1=float(300)
            q2=float(700)
            q3=float(self.var_noOfdays.get())
            q4=float(q1+q2)
            q5=float(q3+q4)
            tax="Rs."+str("%.2f"%((q5)*0.18))
            subtotal="Rs."+str("%.2f"%((q5)))
            totall="Rs."+str("%.2f"%(q5+((q5)*0.18)))
            self.var_paidtax.set(tax)
            self.var_actualtotal.set(subtotal)
            self.var_total.set(totall)

        elif (self.var_meal.get()=="Lunch" and self.var_roomtype.get()=="Luxury"):
            q1=float(300)
            q2=float(700)
            q3=float(self.var_noOfdays.get())
            q4=float(q1+q2)
            q5=float(q3+q4)
            tax="Rs."+str("%.2f"%((q5)*0.18))
            subtotal="Rs."+str("%.2f"%((q5)))
            totall="Rs."+str("%.2f"%(q5+((q5)*0.18)))
            self.var_paidtax.set(tax)
            self.var_actualtotal.set(subtotal)
            self.var_total.set(totall)

        elif (self.var_meal.get()=="Dinner" and self.var_roomtype.get()=="Duplex"):
            q1=float(500)
            q2=float(800)
            q3=float(self.var_noOfdays.get())
            q4=float(q1+q2)
            q5=float(q3+q4)
            tax="Rs."+str("%.2f"%((q5)*0.18))
            subtotal="Rs."+str("%.2f"%((q5)))
            totall="Rs."+str("%.2f"%(q5+((q5)*0.18)))
            self.var_paidtax.set(tax)
            self.var_actualtotal.set(subtotal)
            self.var_total.set(totall)

        else :
            (self.var_meal.get()=="Breakfast" and self.var_roomtype.get()=="Single")
            q1=float(300)
            q2=float(700)
            q3=float(self.var_noOfdays.get())
            q4=float(q1+q2)
            q5=float(q3+q4)
            tax="Rs."+str("%.2f"%((q5)*0.18))
            subtotal="Rs."+str("%.2f"%((q5)))
            totall="Rs."+str("%.2f"%(q5+((q5)*0.18)))
            self.var_paidtax.set(tax)
            self.var_actualtotal.set(subtotal)
            self.var_total.set(totall)


if __name__ == '__main__':
    root=Tk()
    obj=Room_booking(root)
    root.mainloop()