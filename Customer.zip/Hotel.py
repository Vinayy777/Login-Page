from tkinter import *
from PIL import Image,ImageTk
from Customer import Cust_win
from room import Room_booking
from detail import DetailsRooms
class HMS:
    def __init__(self,root):
        self.root=root
        self.root.title("Hotel Management System ")
        self.root.geometry("1270x640+5+10")

        #============================ 1st image===========================
        #Img1=Image.open("C:\\Users\\ABC\\PycharmProjects\\HotelManagementSystem\hotel.png")
        Img1=Image.open(r"C:/Users/ABC/PycharmProjects/HotelManagementSystem/images/hotel images/hotel2.webp")
        #Img1=Image.open(r"C:\Users\ABC\PycharmProjects\HotelManagementSystem\1633410403702hotel-images\hotel images\bed.jpg")
        Img1=Img1.resize((1260,140),Image.BILINEAR)
        self.photoImg1=ImageTk.PhotoImage(Img1)

        lblimg=Label(self.root,image=self.photoImg1,bd=4,relief=RIDGE)
        lblimg.place(x=0,y=0,width=1270,height=140)


        #================= Logo =======================================
        Img2 = Image.open(r"C:\Users\ABC\PycharmProjects\HotelManagementSystem\images\hotel images\logohotel.png")
        Img2 = Img2.resize((230, 140), Image.BILINEAR)
        self.photoImg2 = ImageTk.PhotoImage(Img2)

        lblimg = Label(self.root, image=self.photoImg2, bd=4, relief=RIDGE)
        lblimg.place(x=0, y=0, width=230, height=140)

        lbl_title = Label(self.root,text="HOTEL MANAGEMENT SYSTEM",font=("times new roman",40,"bold"),bg="black",fg="gold",relief=RIDGE,bd=4)
        lbl_title.place(x=0,y=140,width=1540, height=50)

        #====================== Min frame ==========================
        main_frame=Frame(self.root,bd=5,relief="sunken")
        main_frame.place(x=0,y=190,width=1550,height=620)

        #========================Menu =============================
        lbl_menu = Label(main_frame, text="MENU", font=("times new roman", 20, "bold"), bg="black",fg="gold", relief=RIDGE, bd=4)
        lbl_menu.place(x=0, y=0, width=230)

        #======================== btn frame========================
        btn_frame = Frame(main_frame, bd=5, relief="sunken")
        btn_frame.place(x=0, y=35, width=228, height=190)

        cust_btn = Button(btn_frame, text="CUSTOMER",command=self.cust_details,width=22, font=("times new roman", 14, "bold"),bd=0, bg="black",fg="gold",cursor="hand1")
        cust_btn.grid(row=0, column=0,padx=1, pady=1,sticky=E)

        room_btn = Button(btn_frame,command=self.roombooking, text="ROOM", width=22, font=("times new roman", 14, "bold"), bd=0, bg="black",fg="gold",cursor="hand2")
        room_btn.grid(row=1, column=0,padx=1, pady=1)

        details_btn = Button(btn_frame, text="DETAILS",command=self.detailsroom ,width=22, font=("times new roman", 14, "bold"), bd=0, bg="black",fg="gold",cursor="hand2")
        details_btn.grid(row=2, column=0,padx=1, pady=1)

        report_btn = Button(btn_frame, text="REPORT", width=22, font=("times new roman", 14, "bold"), bd=0, bg="black",fg="gold",cursor="hand2")
        report_btn.grid(row=3, column=0,padx=1, pady=1)

        logout_btn = Button(btn_frame, text="LOGOUT", command=self.logout,width=22, font=("times new roman", 14, "bold"), bd=0, bg="black",fg="gold",cursor="hand2")
        logout_btn.grid(row=4, column=0,padx=1, pady=1)

        # ================= right side image =======================================
        Img3 = Image.open( r"C:\Users\ABC\PycharmProjects\HotelManagementSystem\images\hotel images\hotel3.webp")
        Img3 = Img3.resize((1050, 450), Image.BILINEAR)
        self.photoImg3 = ImageTk.PhotoImage(Img3)

        lblimg1 = Label(main_frame, image=self.photoImg3, bd=4, relief=RIDGE)
        lblimg1.place(x=225, y=0, width=1050, height=450)

        # ================= down image =======================================
        Img4 = Image.open(r"C:\Users\ABC\PycharmProjects\HotelManagementSystem\images\hotel images\myh.jpg")
        Img4 = Img4.resize((220, 200), Image.BILINEAR)
        self.photoImg4 = ImageTk.PhotoImage(Img4)

        lblimg2 = Label(main_frame, image=self.photoImg4, bd=4, relief=RIDGE)
        lblimg2.place(x=0, y=220, width=226, height=230)#h=outside image size,y=inside

        # Img5 = Image.open(r"C:\Users\ABC\PycharmProjects\HotelManagementSystem\1633410403702hotel-images\hotel images\khana.jpg")
        '''Img5 = Img5.resize((225, 190), Image.BILINEAR)
                self.photoImg5 = ImageTk.PhotoImage(Img5)

                lblimg3 = Label(main_frame, image=self.photoImg5, bd=4, relief=RIDGE)
                lblimg3.place(x=0, y=230, width=225, height=200)'''

    def cust_details(self):
        self.new_window=Toplevel(self.root)
        self.app=Cust_win(self.new_window)

    def roombooking(self):
        self.new_window=Toplevel(self.root)
        self.app=Room_booking(self.new_window)

    def detailsroom(self):
        self.new_window=Toplevel(self.root)
        self.app=DetailsRooms(self.new_window)

    def logout(self):
        self.root.destroy()



if __name__ == '__main__':
    root=Tk()
    obj=HMS(root)
    root.mainloop()